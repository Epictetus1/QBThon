import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-triggermails',
  templateUrl: './triggermails.component.html',
  styleUrls: ['./triggermails.component.scss']
})
export class TriggermailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
