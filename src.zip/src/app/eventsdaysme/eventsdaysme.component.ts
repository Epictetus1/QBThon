import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eventsdaysme',
  templateUrl: './eventsdaysme.component.html',
  styleUrls: ['./eventsdaysme.component.scss']
})
export class EventsdaysmeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
